if (!CKEDITOR.instances[id]) {
    CKEDITOR.replace(id, settings);
}
